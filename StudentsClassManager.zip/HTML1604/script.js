let alunos = [];

document.getElementById("bttCadastrar").addEventListener("click", adicionarAluno);
document.getElementById("bttRank").addEventListener("click", mostrarTop);

function adicionarAluno(){
    let nome = document.getElementById("nomeAluno").value;
    let nota1 = Number(document.getElementById("nota1").value);
    let nota2 = Number(document.getElementById("nota2").value);

    if (!nome || nota1 === 0 || nota2 === 0){
        alert("Preencha todos os campos!");
        return;
    }

    let media = (nota1 + nota2) / 2;
    let status = media >= 7 ? "Aprovado" : "Reprovado";

    let aluno = {
        nome,
        nota1,
        nota2,
        media,
        status
    };

    alunos.push(aluno);

    alert(`Aluno ${nome} cadastrado com sucesso!`);

    limparCampo();
    exibirAlunos(alunos);
}

function exibirAlunos(listaExibicao){
    let texto = listaExibicao.map(f => 
        `<br>Aluno: <b>${f.nome}</b><br>
         Nota 1: ${f.nota1} — Nota 2: ${f.nota2}<br>
         Média: ${f.media.toFixed(2)} — ${f.status}`
    ).join("");

    document.getElementById("listarAlunos").innerHTML = texto, "<br>";
}

function limparCampo(){
    document.getElementById("nomeAluno").value = "";
    document.getElementById("nota1").value = "";
    document.getElementById("nota2").value = "";
}

function mostrarTop(){
    let top5 = [...alunos]
        .sort((a, b) => b.media - a.media)
        .slice(0, 5);

    exibirAlunos(top5);
}